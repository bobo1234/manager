package com.java.back.constant;

public class AccountDeleteState {

	/*
	 * 删除
	 *   
	 */
	public static final boolean IS_DELETE = true;

	/*
	 * 未删除
	 *   
	 */
	public static final boolean NO_DELETE = false;

}

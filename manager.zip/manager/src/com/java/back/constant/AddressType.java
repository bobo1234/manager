package com.java.back.constant;

public class AddressType {

	/*
	 * 户籍地址
	 *   
	 */
	public static final int REGISTER = 1;

	/*
	 * 现居住地址
	 *   
	 */
	public static final int CURRENT = 2;

}

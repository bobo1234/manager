package com.java.back.constant;

public class SessionKey {

	/*
	 * 账户登录session账户名称
	 *   
	 */
	public static final String MODULEACCTNAME = "acctName";
	/*
	 * 账户登录session账户ID
	 *   
	 */
	public static final String acctId = "acctId";

	/*
	 * 验证码
	 *   
	 */
	public static final String VALIDATE_CODE = "VALIDATECODE";

}

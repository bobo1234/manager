package com.java.back.constant;

public class PageConstant {

	/*
	 * 普通数据列表
	 *   
	 */
	public static final int PAGE_LIST = 15;

}

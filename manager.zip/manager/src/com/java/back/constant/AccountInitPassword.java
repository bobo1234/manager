package com.java.back.constant;

public class AccountInitPassword {

	/*
	 * 初始化密码
	 */
	public static final String ACCOUNT_INIT_PASSWORD = "123456";

}

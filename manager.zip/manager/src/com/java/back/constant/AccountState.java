package com.java.back.constant;

public class AccountState {

	/*
	 * 普通会员
	 *   
	 */
	public static final int ACCOUNT_GENERAL = 0;

}

package com.java.back.constant;

public class PhoneImageSize {

	/**
	 * 图片上传最大不操作10MB
	 */
	public static final int PHONE_IMAGE_SIZE = 1024 * 10000;

}

package com.java.back.field;

public class TeCityField {

	public static final String CITY_NAME = "cityName";
	public static final String CITY_CODE = "cityCode";
	public static final String PROVINCE_ID = "provinceId";

}
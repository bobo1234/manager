package com.java.back.field;

public class TeRoleField {

	//property constants
	public static final String ROLE_ID = "roleId";
	public static final String ROLE_NAME = "roleName";
	public static final String ROLE_LABEL = "roleLabel";
	public static final String CREATOR = "creator";

}
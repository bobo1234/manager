package com.java.back.field;

public class TeEmployeesLogField {

	//property constants
	public static final String EMPL_ID = "emplId";
	public static final String TYPE = "type";
	public static final String NOTE = "note";
	public static final String CREATOR = "creator";

}
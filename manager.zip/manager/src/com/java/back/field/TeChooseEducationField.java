package com.java.back.field;

public class TeChooseEducationField {

	//property constants
	public static final String EDU_NAME = "eduName";

}
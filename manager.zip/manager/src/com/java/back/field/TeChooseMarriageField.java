package com.java.back.field;

public class TeChooseMarriageField {
	
	public static final String MAR_NAME = "marName";
	
}
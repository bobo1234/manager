package com.java.back.field;

public class TeVillageField {

	public static final String VILLAGE_NAME = "villageName";
	public static final String VILLAGE_CODE = "villageCode";
	public static final String TOWNSHIP_ID = "townshipId";

}
package com.java.back.field;

public class TeTownshipField {

	public static final String TOWNSHIP_NAME = "townshipName";
	public static final String TOWNSHIP_CODE = "townshipCode";
	public static final String COUNTY_ID = "countyId";

}
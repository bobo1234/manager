package com.java.back.field;

public class TeEmployeesDetailField {

	public static final String EMPL_NO = "emplNo";
	public static final String EM_CONTACT = "emContact";
	public static final String EM_EMERGENCY_CONTACT = "emEmergencyContact";
	public static final String EM_EMERGENCY_PHONE = "emEmergencyPhone";
	public static final String EM_SCHOOL = "emSchool";
	public static final String EM_PROFESSIONAL = "emProfessional";
	public static final String EM_GRADUATION_TIME = "emGraduationTime";
	public static final String EM_SCHOOLING = "emSchooling";
	public static final String EM_DEGREE = "emDegree";
	public static final String EM_IS_SOCIAL_SECURITY = "emIsSocialSecurity";
	public static final String EM_NOTE = "emNote";

}
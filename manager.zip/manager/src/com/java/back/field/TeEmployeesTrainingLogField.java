package com.java.back.field;

public class TeEmployeesTrainingLogField {

	//property constants
	public static final String STATE = "state";
	public static final String EMPL_ID = "emplId";
	public static final String TRAINING_ITEM_ID = "trainingItemId";
	public static final String APPLY_TIME = "applyTime";
	public static final String NOTE = "note";
	public static final String CREATOR = "creator";

}
package com.java.back.field;

public class TeChooseNationalField {
	
	//property constants
	public static final String NAT_NAME = "natName";
	
}
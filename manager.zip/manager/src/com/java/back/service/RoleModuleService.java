package com.java.back.service;

public interface RoleModuleService {
	
}

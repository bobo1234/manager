var moduleCode = '02001';
function initFun() {
}
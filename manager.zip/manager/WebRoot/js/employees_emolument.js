var moduleCode = '02002';
function initFun() {
}